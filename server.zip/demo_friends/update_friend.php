<?php 


require_once 'connect.php';

if($_SERVER['REQUEST_METHOD']=='POST') {

$key = $_POST['key'];

if ( $key == "update" ){

    $id         = $_POST['id'];
    $nama       = $_POST['nama'];
    $hobi       = $_POST['hobi'];
    $profesi    = $_POST['profesi'];
    $kelamin    = $_POST['kelamin'];
    $birth      = $_POST['birth'];
    $picture    = $_POST['picture'];

    $birth =  date('Y-m-d', strtotime($birth));

    $query = "UPDATE friends SET 
    nama='$nama', 
    hobi='$hobi', 
    profesi='$profesi',
    kelamin='$kelamin',
    birth='$birth' 
    WHERE id='$id' ";

        if ( mysqli_query($conn, $query) ){

            if ($picture == null) {

                $response["value"] = "1";
                $response["message"] = "Success";
    
                echo json_encode($response);
                mysqli_close($conn);

            } else {

                $path = "friends_picture/$id.jpeg";
                $finalPath = "/demo_friends/".$path;

                $insert_picture = "UPDATE friends SET picture='$finalPath' WHERE id='$id' ";
            
                if (mysqli_query($conn, $insert_picture)) {
            
                    if ( file_put_contents( $path, base64_decode($picture) ) ) {
                        
                        $response["value"] = "1";
                        $response["message"] = "Success!";
            
                        echo json_encode($response);
                        mysqli_close($conn);
            
                    } else {
                        
                        $response["value"] = "0";
                        $response["message"] = "Error! ".mysqli_error($conn);
                        echo json_encode($response);

                        mysqli_close($conn);
                    }

                }
            }

        } 
        else {
            $response["value"] = "0";
            $response["message"] = "Error! ".mysqli_error($conn);
            echo json_encode($response);

        }

      }

     mysqli_close($conn);
}

?>
