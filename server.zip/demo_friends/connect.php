<?php 
define('host', 'localhost');
define('user', 'root');
define('pass', '');
define('db', 'friendss_db');

$conn = mysqli_connect(host, user, pass, db) or die('YES');
?>
