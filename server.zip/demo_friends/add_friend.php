<?php 

require_once 'connect.php';

if($_SERVER['REQUEST_METHOD']=='POST') {

$key        = $_POST['key'];

$nama       = $_POST['nama'];
$hobi       = $_POST['hobi'];
$profesi    = $_POST['profesi'];
$kelamin    = $_POST['kelamin'];
$birth      = $_POST['birth'];
$picture    = $_POST['picture'];

if ( $key == "insert" ){

    $birth_newformat = date('Y-m-d', strtotime($birth));

    $query = "INSERT INTO friends (nama,hobi,profesi,kelamin,birth)
    VALUES ('$nama', '$hobi', '$profesi', '$kelamin', '$birth_newformat') ";

        if ( mysqli_query($conn, $query) ){

            if ($picture == null) {

                $finalPath = "/demo_friends/friend_logo.png"; 
                $response["value"] = "1";
                $response["message"] = "Success";
    
                echo json_encode($response);

            } else {

                $id = mysqli_insert_id($conn);
                $path = "friends_picture/$id.jpeg";
                $finalPath = "/demo_friends/".$path;

                $insert_picture = "UPDATE friends SET picture='$finalPath' WHERE id='$id' ";
            
                if (mysqli_query($conn, $insert_picture)) {
            
                    if ( file_put_contents( $path, base64_decode($picture) ) ) {
                        
                        $response["value"] = "1";
                        $response["message"] = "Success!";
            
                        echo json_encode($response);
            
                    } else {
                        
                        $response["value"] = "0";
                        $response["message"] = "Error! ".mysqli_error($conn);
                        echo json_encode($response);

                    }

                }
            }

        } 
        else {
            $response["value"] = "0";
            $response["message"] = "Error! ".mysqli_error($conn);
            echo json_encode($response);

           
        }

    }

    mysqli_close($conn);

}

?>
